 f95 nsphere1.for -o nsphere1
  ./nsphere1 inp.text
 f95 csca.for -o csca
 ./csca
